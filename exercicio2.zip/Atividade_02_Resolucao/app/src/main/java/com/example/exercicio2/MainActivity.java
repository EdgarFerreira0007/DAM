package com.example.exercicio2;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // 1. Encontrar a caixinha do XML pelo ID
        Spinner spinnerOperadores = findViewById(R.id.spinner);

        // 2. Criar a lista de símbolos
        String[] operadores = {"+", "-", "*", "/"};

        // 3. Criar o adaptador
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, operadores);

        // 4. Definir o estilo visual da lista aberta
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        // 5. Entregar a lista ao Spinner
        spinnerOperadores.setAdapter(adapter);

        // --- LÓGICA DA CALCULADORA (BOTÃO E CÁLCULO) ---

        // Encontrar os elementos da interface pelos IDs
        EditText editText1 = findViewById(R.id.editTextText);
        EditText editText2 = findViewById(R.id.editTextText2);
        Button btnCalcular = findViewById(R.id.button);
        TextView tvResultado = findViewById(R.id.tvResultado);

        // Ação de clique no botão
        btnCalcular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String str1 = editText1.getText().toString();
                String str2 = editText2.getText().toString();

                // Validar se os campos estão preenchidos para evitar crashs
                if (str1.isEmpty() || str2.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Preencha os campos", Toast.LENGTH_SHORT).show();
                    return;
                }

                // Converter o texto para números
                Double num1 = Double.parseDouble(str1);
                Double num2 = Double.parseDouble(str2);
                Double resultado = 0.0;

                // Obter operador selecionado
                String operador = spinnerOperadores.getSelectedItem().toString();

                boolean operacaoValida = true;

                // Fazer o cálculo consoante o operador escolhido
                switch (operador) {
                    case "+":
                        resultado = num1 + num2;
                        break;
                    case "-":
                        resultado = num1 - num2;
                        break;
                    case "*":
                        resultado = num1 * num2;
                        break;
                    case "/":
                        if (num2 == 0) {
                            Toast.makeText(MainActivity.this, "Não é possível dividir por zero", Toast.LENGTH_SHORT).show();
                            operacaoValida = false;
                        } else {
                            resultado = num1 / num2;
                        }
                        break;
                    default:
                        Toast.makeText(MainActivity.this, "Operador inválido", Toast.LENGTH_SHORT).show();
                        operacaoValida = false;
                        break;
                }

                // Mostrar o resultado se for válido
                if (operacaoValida) {
                    tvResultado.setText("Resultado: " + resultado);
                    tvResultado.setVisibility(View.VISIBLE);
                }
            }
        });
    }
}